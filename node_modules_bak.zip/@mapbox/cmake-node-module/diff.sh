#!/usr/bin/env bash

set -euo pipefail


VERSIONS=$(find node -type d -depth 1 -name "v10.*" | sort --version-sort)

PREV=
for CUR in $VERSIONS ; do
    if [ ! -z "$PREV" ]; then
        DIFF=$(diff -u "$PREV/node_api.h" "$CUR/node_api.h" || true)
        if [ ! -z "$DIFF" ]; then
            echo "$CUR:"
            echo "$DIFF"
            echo -e "\n\n=================================================================================\n\n"
        fi
    fi
    PREV="$CUR"
done