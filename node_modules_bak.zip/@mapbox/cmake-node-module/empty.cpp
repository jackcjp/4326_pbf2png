// An empty .cpp file used to suppress the CMake warning when adding a new
// shared library target without source files.
