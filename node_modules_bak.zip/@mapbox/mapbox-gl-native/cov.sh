#!/bin/bash

set -eu
set -o pipefail

mkdir -p cov-build
rm -rf cov-build/*
export OUTPUT_DIR=$(pwd)/out

# takes too long to download in china, so disabled for now
# once this works can port to alt coverage format: https://github.com/mapbox/cpp/blob/master/docs/coverage.md
# ./scripts/mason.sh INSTALL clang++ VERSION 6.0.1
# export CXX=$(./scripts/mason.sh PREFIX clang++ VERSION 6.0.1)/bin/clang++
# export CC=$(./scripts/mason.sh PREFIX clang++ VERSION 6.0.1)/bin/clang
export CXX=clang++
export CC=clang

./scripts/mason.sh INSTALL cmake VERSION 3.8.2
export MASON_CMAKE=$(./scripts/mason.sh PREFIX cmake VERSION 3.8.2)/bin/cmake
./scripts/mason.sh INSTALL ccache VERSION 3.3.4
export MASON_CCACHE=$(./scripts/mason.sh PREFIX ccache VERSION 3.3.4)/bin/ccache
./scripts/mason.sh INSTALL ninja VERSION 1.7.2
export MASON_NINJA=$(./scripts/mason.sh PREFIX ninja VERSION 1.7.2)/bin/ninja

cd cov-build
${MASON_CMAKE} ../ \
      -DCMAKE_INSTALL_PREFIX=${OUTPUT_DIR} -DCMAKE_BUILD_TYPE=Debug \
      -DWITH_NODEJS=OFF -DWITH_ERROR=OFF \
      -G Ninja -DCMAKE_MAKE_PROGRAM=${MASON_NINJA} \
      -DCMAKE_CXX_COMPILER_LAUNCHER=${MASON_CCACHE} \
      -DCMAKE_CXX_COMPILER="$CXX" \
      -DCMAKE_C_COMPILER="$CC" \
      -DCMAKE_CXX_FLAGS="--coverage" \
      -DCMAKE_SHARED_LINKER_FLAGS="--coverage"

${MASON_NINJA} mbgl-test -j4 -v
