function mason_prepare_compile {
    CCACHE_VERSION=3.7.2
    CMAKE_VERSION=3.15.2
    NINJA_VERSION=1.9.0
    LLVM_VERSION=9.0.0
    ../mason/mason install clang++ ${LLVM_VERSION}
    MASON_LLVM=$(../mason/mason prefix clang++ ${LLVM_VERSION})
    ../mason/mason install ccache ${CCACHE_VERSION}
    MASON_CCACHE=$(../mason/mason prefix ccache ${CCACHE_VERSION})
    ../mason/mason install cmake ${CMAKE_VERSION}
    MASON_CMAKE=$(../mason/mason prefix cmake ${CMAKE_VERSION})
    ../mason/mason install ninja ${NINJA_VERSION}
    MASON_NINJA=$(../mason/mason prefix ninja ${NINJA_VERSION})
}

ReleaseType="Debug"

function mason_compile {
    mkdir -p build-${ReleaseType}
    rm -rf build-${ReleaseType}/*
    cd build-${ReleaseType}
    # export CXXFLAGS="-D_LIBCPP_HAS_NO_ASAN=1 -fsanitize=address,leak"
    # export LDFLAGS="-fsanitize=address,leak"
    # export ASAN_OPTIONS=detect_leaks=1:color=always:print_summary=1
    ${MASON_CMAKE}/bin/cmake ../ \
      -DCMAKE_INSTALL_PREFIX=${MASON_PREFIX} -DCMAKE_BUILD_TYPE=${ReleaseType} \
      -G Ninja -DCMAKE_MAKE_PROGRAM=${MASON_NINJA}/bin/ninja \
      -DWITH_EGL=OFF \
      -DCMAKE_CXX_COMPILER_LAUNCHER=${MASON_CCACHE}/bin/ccache \
      -DCMAKE_CXX_COMPILER="${MASON_LLVM}/bin/clang++" \
      -DCMAKE_C_COMPILER="${MASON_LLVM}/bin/clang"
      #-DMBGL_PLATFORM=linux
    ${MASON_NINJA}/bin/ninja mbgl-render -j6
    # export DYLD_INSERT_LIBRARIES=${HOME}/projects/mbgl/mason_packages/osx-x86_64/swiftshader/2018-05-31/lib/libEGL.dylib:${HOME}/projects/mbgl/mason_packages/osx-x86_64/swiftshader/2018-05-31/lib/libGLESv2.dylib
    #export DYLD_INSERT_LIBRARIES=${DYLD_INSERT_LIBRARIES}:${HOME}/projects/mbgl/mason_packages/osx-x86_64/clang++/8.0.0/lib/clang/8.0.0/lib/darwin/libclang_rt.asan_osx_dynamic.dylib
    # ./mbgl-test
    #${MASON_NINJA}/bin/ninja mbgl-render-test -j4 -v

}

mason_prepare_compile
mason_compile
