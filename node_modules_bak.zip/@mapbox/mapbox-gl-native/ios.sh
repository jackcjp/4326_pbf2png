# brew install cmake ccache
git submodule update --init mapbox-gl-js
scripts/nitpick/submodule-pin.js
scripts/nitpick/generated-code.js cmake
npm install
build-ios-test
