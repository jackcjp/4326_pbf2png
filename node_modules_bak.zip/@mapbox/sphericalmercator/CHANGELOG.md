## v1.1.0

- Add support for floating point zoom levels in `ll` and `px` methods (@orionstein) [#32](https://github.com/mapbox/sphericalmercator/pull/32)

## v1.0.5

- If any x or y produced by `.xyz()` are negative, set them to zero
